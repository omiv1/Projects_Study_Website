// const mongoose = require('mongoose');

// mongoose.connect('mongodb://localhost/eu_projects', { useNewUrlParser: true, useUnifiedTopology: true });

// mongoose.connection.on('connected', () => {
//   console.log('Connected to MongoDB');
// });

// mongoose.connection.on('error', (err) => {
//   console.log('Error connecting to MongoDB:', err);
// });

// const mongoose = require('mongoose');

// const connectDB = () => {
//     mongoose.connect("mongodb+srv://admin:1234@cluster0.zyw0jv5.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0", {
//         useNewUrlParser: true,
//         useUnifiedTopology: true
//     })
//     .then(() => {
//         console.log("Połączono z bazą");
//     }).catch((err) => {
//         console.log("Nie można połączyć się z MongoDB. Błąd: " + err);
//     });
// }

// module.exports = connectDB;
