<?php

declare(strict_types=1);

return [
    'next'     => 'Następna &raquo;',
    'previous' => '&laquo; Poprzednia',
];
