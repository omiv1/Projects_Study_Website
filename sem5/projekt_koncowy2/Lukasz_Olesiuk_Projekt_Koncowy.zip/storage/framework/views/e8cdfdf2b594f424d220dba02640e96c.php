<nav class="navbar navbar-expand-md navbar-light shadow-sm">
    <div class="container">
        <!-- Language Links -->
        <div class="mr-auto">
            <a href="<?php echo e(route('lang.switch', 'en')); ?>" class="mr-3" > EN </a>
            <a href="<?php echo e(route('lang.switch', 'pl')); ?>" class="mr-3" > PL </a>
        </div>

        <!-- Authentication Links -->
        <div class="ml-auto">
            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="mr-3" > <?php echo app('translator')->get('my_name.login'); ?> </a>
                <a href="<?php echo e(route('register')); ?>" > <?php echo app('translator')->get('my_name.register'); ?> </a>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('profile.edit')); ?>" class="mr-3" > <?php echo e(Auth::user()->name); ?> </a>
                <a href="<?php echo e(route('logout')); ?>" > <?php echo app('translator')->get('my_name.logout'); ?> </a>


            <?php endif; ?>
        </div>
    </div>
</nav>
<?php if(auth()->guard()->check()): ?>
    <?php if(Auth::user()->role == 'moderator'): ?>
<nav class="navbar navbar-expand-md navbar-light shadow-sm">
    <div class="container">

        <!-- Authentication Links -->
            <a href="<?php echo e(route('addCategory')); ?>" class="btn btn-primary"> <?php echo app('translator')->get('my_name.addCategory'); ?> </a>
            <a href="<?php echo e(route('addSubCategory')); ?>" class="btn btn-primary"> <?php echo app('translator')->get('my_name.addSubCategory'); ?> </a>
        <a href="<?php echo e(route('categoriesWithSubcategories')); ?>" class="btn btn-primary"> <?php echo app('translator')->get('my_name.category'); ?> </a>

    </div>
</nav>
<?php endif; ?>
<?php endif; ?>
<nav class="navbar navbar-expand-md navbar-light shadow-sm">
    <div class="container">

        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('imgs/logo.png')); ?>" style="height: 80px; width: auto;" alt="<?php echo app('translator')->get('my_name.home'); ?>">
        </a>
        <?php if(auth()->guard()->check()): ?>

        <a href="<?php echo e(route('addDeal')); ?>" class="btn btn-primary"> <?php echo app('translator')->get('my_name.addDeal'); ?> </a>
        <?php endif; ?>
        <a href="<?php echo e(route('deals')); ?>" class="btn btn-primary"> <?php echo app('translator')->get('my_name.deals'); ?> </a>

        <!-- Authentication Links -->
        
        
        

    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\projekt_koncowy\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>