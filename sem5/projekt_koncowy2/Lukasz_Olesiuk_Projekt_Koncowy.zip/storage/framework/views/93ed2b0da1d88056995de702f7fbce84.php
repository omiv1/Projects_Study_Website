


<img src="<?php echo e(asset('imgs/logo.png')); ?>" class="h-16 w-auto">
<?php /**PATH C:\xampp\htdocs\projekt_koncowy\resources\views/components/application-logo.blade.php ENDPATH**/ ?>