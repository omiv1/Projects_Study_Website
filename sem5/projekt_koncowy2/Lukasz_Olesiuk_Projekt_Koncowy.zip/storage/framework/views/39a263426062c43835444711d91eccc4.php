<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <title>TAI | Szczegóły okazji</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <style>
        .points-badge {
            position: absolute;
            top: 0;
            left: 0;
            background-color: rgba(230, 230, 230, 0.9); /* Lekko przezroczysty szary */
            padding: 5px 10px;
            border-bottom-right-radius: 50%; /* Półokrągły narożnik */
            width: 75px; /* Szerokość narożnika */
            height: 75px; /* Wysokość narożnika */
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5em; /* Powiększ czcionkę */
            font-weight: bold; /* Pogrub czcionkę */
        }
        .deal-points-container {
            display: inline-block;
            border: 2px solid #b6b6b6;
            border-radius: 50%;
            padding: 10px;
            background-color: #575757;
        }

        .deal-points {
            font-size: 24px;
            color: white;
            padding: 10px;
            border-radius: 5px;
        }

        .clicked {
            background-color: #ffce09 !important;
        }
    </style>
</head>
<body>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <h1>Szczegóły okazji</h1>
    <div class="row">
        <div class="col-md-6">
            <img src="<?php echo e($deal->image_link); ?>" alt="<?php echo e($deal->name); ?>" class="bd-placeholder-img card-img-top" style="max-height: 350px; width: auto; object-fit: contain;">
            <div id="deal-points" class="points-badge" data-points="<?php echo e($deal->points); ?>"><?php echo e($deal->points); ?></div>
        </div>
        <div class="col-md-6">
            <div class="card-body">



                <?php if(Auth::check()): ?>
                    <button id="upvote-button" class="btn btn-success <?php echo e($user_vote == 1 ? 'clicked' : ''); ?>" onclick="rateDeal(<?php echo e($deal->id); ?>, 1)">
                        <i class="fas fa-thumbs-up"></i>
                    </button>
                    <button id="downvote-button" class="btn btn-danger <?php echo e($user_vote == -1 ? 'clicked' : ''); ?>" onclick="rateDeal(<?php echo e($deal->id); ?>, -1)">
                        <i class="fas fa-thumbs-down"></i>
                    </button>
                <?php endif; ?>
                <h5 class="card-title"><?php echo e($deal->name); ?></h5>
                <p class="card-text">
                    Producent: <?php echo e($deal->manufacturer); ?><br>
                    Model: <?php echo e($deal->model); ?><br>
                    Kod produktu: <?php echo e($deal->product_code); ?><br>
                    Cena: <?php echo e($deal->price); ?><br>
                    Dodano: <?php echo e($deal->added_at); ?><br>
                    <a href="<?php echo e($deal->deal_link); ?>" class="btn btn-primary" target="_blank">Przejdź do strony</a>
                </p>
            </div>
        </div>
    </div>
</div>




































<script>
    function rateDeal(dealId, points) {
        fetch('/deals/rate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: JSON.stringify({
                deal_id: dealId,
                points: points
            })
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error("HTTP error " + response.status);
                }
                return response.json();
            })
            .then(json => {
                let dealPointsElement = document.getElementById('deal-points');
                if (dealPointsElement) {
                    dealPointsElement.textContent = json.points;
                } else {
                    console.error("Element 'deal-points' does not exist in the DOM.");
                }

                let upvoteButton = document.getElementById('upvote-button');
                let downvoteButton = document.getElementById('downvote-button');

                if (points == 1) {
                    if (upvoteButton && downvoteButton) {
                        if (upvoteButton.classList.contains('clicked')) {
                            upvoteButton.classList.remove('clicked');
                        } else {
                            upvoteButton.classList.add('clicked');
                            downvoteButton.classList.remove('clicked');
                        }
                    }
                } else {
                    if (upvoteButton && downvoteButton) {
                        if (downvoteButton.classList.contains('clicked')) {
                            downvoteButton.classList.remove('clicked');
                        } else {
                            downvoteButton.classList.add('clicked');
                            upvoteButton.classList.remove('clicked');
                        }
                    }
                }
            })
            .catch(function(error) {
                console.error("Fetch request failed: ", error);
            });
    }

    window.onload = function() {
        var badges = document.querySelectorAll('.points');
        badges.forEach(function(badge) {
            var points = badge.getAttribute('data-points');
            if (points > 0) {
                badge.style.color = 'red';
            } else if (points < 0) {
                badge.style.color = 'blue';
            } else {
                badge.style.color = 'black';
            }
        });
    };
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\projekt_koncowy\resources\views/deal.blade.php ENDPATH**/ ?>