<nav class="navbar navbar-expand-md navbar-light shadow-sm">
    <div class="container">
        <a href="<?php echo e(url('/')); ?>"> Home </a>
        <a href="<?php echo e(route('comments')); ?>"> Komentarze </a>

        <!-- Authentication Links -->
        <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('login')); ?>">Login</a>
        <?php endif; ?>

    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\lab12\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>