<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <title>TAI | Komentarze</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.15.5/dist/bootstrap-table.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/bootstrap-table@1.15.5/dist/bootstrap-table.min.js"></script>
    <style>
        body{
            background-color: #e8e8e8;
        }
        .title{
            text-align: center;
            background-color: transparent
        }
        .table-container{
            background-color: white;
            max-width: 900px;
            margin: 0 auto;
        }
        .footer-button{
            background-color: transparent;
            float: right;
            margin-top: 3%;
        }
        table{
            max-width: 800px;
            margin: 0 auto;
        }
    </style>
</head>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<div class="table-container">
    <div class="title">
        <h3>Księga komentarzy</h3>
    </div>
    <?php if(auth()->guard()->check()): ?>
        <table data-toggle="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Użytkownik</th>
                <th>Data dodania</th>
                <th>Komentarz</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($comment->id); ?></td>
                    <td><?php echo e($comment->user->name); ?></td>
                    <td><?php echo e($comment->created_at); ?></td> <!-- Zmienione z $comment->date -->
                    <td><?php echo e($comment->message); ?>

                        <br /> <?php if($comment->user_id == \Auth::user()->id): ?>
                            <a href="<?php echo e(route('edit', $comment)); ?>"
                               class="btn btn-success btn-xs"
                               title="Edytuj"> Edytuj
                            </a>

                            <a href="<?php echo e(route('delete', $comment->id)); ?>"
                               class="btn btn-danger btn-xs"
                               onclick="return confirm('Jesteś pewien?')"
                               title="Skasuj"> Usuń
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="footer-button">
            <a href="<?php echo e(route('create')); ?>" class="btn btn-secondary">Dodaj</a>
        </div>
        <br>
    <?php endif; ?>
</div>

<?php if(auth()->guard()->guest()): ?>
    <div class="table-container">
        <b>Zaloguj się aby przejrzeć komentarze.</b>
    </div>
<?php endif; ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\lab12\resources\views/comments.blade.php ENDPATH**/ ?>