<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TAI | Dodaj deal</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.15.5/dist/bootstrap-table.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/bootstrap-table@1.15.5/dist/bootstrap-table.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        body{
            background-color: #e8e8e8;
        }
        .title{
            text-align: center;
            background-color: transparent
        }
        .table-container{
            background-color: white;
            max-width: 900px;
            margin: 0 auto;
        }
        .box {
            display: flex;
            justify-content: center;
        }
        .box-footer{
            float: right;
        }
    </style>
</head>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



















































































































<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-center"><h3>Dodaj ofertę</h3></div>
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('storeDeal')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="manufacturer"><?php echo app('translator')->get('my_name.manufacturer'); ?>:</label>
                                <input type="text" id="manufacturer" name="manufacturer" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="deal_link"><?php echo app('translator')->get('my_name.deal_link'); ?>:</label>
                                <input type="text" id="deal_link" name="deal_link" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="image_link"><?php echo app('translator')->get('my_name.image_link'); ?>:</label>
                                <input type="text" id="image_link" name="image_link" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="model"><?php echo app('translator')->get('my_name.model'); ?>:</label>
                                <input type="text" id="model" name="model" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="name"><?php echo app('translator')->get('my_name.name'); ?>:</label>
                                <input type="text" id="name" name="name" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="product_code"><?php echo app('translator')->get('my_name.product_code'); ?>:</label>
                                <input type="text" id="product_code" name="product_code" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="category_id"><?php echo app('translator')->get('my_name.category'); ?>:</label>
                                <select id="category_id" name="category_id" class="form-control" required>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="subcategory_id"><?php echo app('translator')->get('my_name.subcategory'); ?>:</label>
                                <select id="subcategory_id" name="subcategory_id" class="form-control" required>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="price"><?php echo app('translator')->get('my_name.price'); ?>:</label>
                                <input type="text" id="price" name="price" class="form-control">
                            </div>
                            <div class="form-group mt-3">
                                <input type="submit" value="<?php echo app('translator')->get('my_name.submit'); ?>" class="btn btn-primary">
                            </div>
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    document.getElementById('category_id').addEventListener('change', function() {
        var categoryId = this.value;
        fetch('/get-subcategories/' + categoryId)
            .then(response => response.json())
            .then(data => {
                document.getElementById('subcategory_id').innerHTML = data.html;
            })
            .catch(error => console.error('Error:', error));
    });
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\projekt_koncowy\resources\views/addDealForm.blade.php ENDPATH**/ ?>